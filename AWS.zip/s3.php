<!DOCTYPE html>
<html>
<head>
  <title>AWS Technical Essentials v4.1</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <style>
    h1 {
      font-size: 36px; /* Adjust the font size */
    }
    .form-group {
      margin-bottom: 15px;
    }
  </style>
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <?php include('menu.php'); ?>
        <div class="jumbotron">

          <h3>Test S3 Link</h3>
          <form method="POST" action="">
            <div class="form-group">
              <label for="firstName">First Name:</label>
              <input type="text" id="firstName" name="firstName" class="form-control" placeholder="Enter First Name" required>
            </div>

            <div class="form-group">
              <label for="lastName">Last Name:</label>
              <input type="text" id="lastName" name="lastName" class="form-control" placeholder="Enter Last Name" required>
            </div>

            <div class="form-group">
              <label for="studentId">Student ID:</label>
              <input type="text" id="studentId" name="studentId" class="form-control" placeholder="Enter Student ID" required>
            </div>

            <div class="form-group">
              <label for="s3Link">Enter S3 Link:</label>
              <input type="text" id="s3Link" name="s3Link" class="form-control" placeholder="https://your-bucket.s3.amazonaws.com/yourfile.pdf" required>
            </div>

            <button type="submit" class="btn btn-primary">Test Link</button>
          </form>

          <div id="result">
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $firstName = htmlspecialchars($_POST['firstName']);
                $lastName = htmlspecialchars($_POST['lastName']);
                $studentId = htmlspecialchars($_POST['studentId']);
                $s3Link = htmlspecialchars($_POST['s3Link']);

                echo "<p>Student Info: $firstName $lastName - ID: $studentId</p>";
                echo "<p>S3 Link: <a href=\"$s3Link\" target=\"_blank\">$s3Link</a></p>"; // Display the S3 link

                if (filter_var($s3Link, FILTER_VALIDATE_URL)) {
                    // Initialize cURL session
                    $ch = curl_init($s3Link);
                    curl_setopt($ch, CURLOPT_NOBODY, true);  // Send a HEAD request
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_TIMEOUT, 10);  // Set a 10-second timeout

                    // Execute cURL request
                    curl_exec($ch);
                    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);  // Get the HTTP response code
                    curl_close($ch);

                    // Check if the link is accessible
                    if ($httpCode == 200) {
                        echo "<p style='color:green;'>S3 link is accessible!</p>";
                    } else {
                        echo "<p style='color:red;'>S3 link is not accessible. HTTP Status Code: $httpCode</p>";
                    }
                } else {
                    echo "<p style='color:red;'>Invalid URL format.</p>";
                }

                echo "<p>Current Time: " . date("Y-m-d H:i:s") . "</p>";
            }
            ?>
          </div>

        </div>
      </div>
    </div>
  </div>

  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/scripts.js"></script>
</body>
</html>
